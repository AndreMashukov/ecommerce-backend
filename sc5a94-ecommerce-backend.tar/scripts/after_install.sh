#!/bin/bash
echo "Login to ECR"
# LOGIN_COMMAND